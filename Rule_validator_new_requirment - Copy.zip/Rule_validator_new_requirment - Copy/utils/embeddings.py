from openai import OpenAI
import numpy as np
from utils.openai_client import client

def get_embedding(text):
    res = client.embeddings.create(
        model="text-embedding-3-small",
        input=text
    )
    return np.array(res.data[0].embedding)
