import streamlit as st
import pandas as pd
from agents.rag_engine import SmartRAG
from agents.reranker import rerank_chunks
from agents.content_synthesizer import synthesize_content
from agents.matcher import smart_match
from agents.workflow import build_graph
from utils.file_loader import load_documents
from concurrent.futures import ThreadPoolExecutor

st.title("Smart DRL–DMN Matcher (LangGraph)")

file = st.file_uploader("Upload Excel")
folder = st.text_input("Docs folder path")

def row_to_text(row):
    return ", ".join([f"{k}:{v}" for k,v in row.items()])

if st.button("Run"):
    df = pd.read_excel(file)
    docs = load_documents(folder)
    rag = SmartRAG(docs)

    graph = build_graph(row_to_text, synthesize_content, smart_match)

    def process(i, row):
        content1 = row_to_text(row)
        chunks = rag.retrieve(content1)
        top_chunks = rerank_chunks(content1, chunks)

        state = {
            "row": row.to_dict(),
            "chunks": top_chunks
        }

        result = graph.invoke(state)

        return {
            "Row ID": i,
            "Rule1": result["content1"],
            "Rule2": result["content2"],
            "Match": result["result"]
        }

    with ThreadPoolExecutor(max_workers=8) as ex:
        results = list(ex.map(lambda x: process(x[0], x[1]), df.iterrows()))

    st.dataframe(pd.DataFrame(results))
