from openai import OpenAI
from utils.openai_client import client
import os

def synthesize_content(content1, chunks):
    context = "\n".join(chunks)
    prompt = f"Extract business rule from:\n{context}"
    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return res.choices[0].message.content
