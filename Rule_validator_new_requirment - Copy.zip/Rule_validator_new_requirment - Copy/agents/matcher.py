from openai import OpenAI

from utils.openai_client import client


def smart_match(rule1, rule2):
    prompt = f"Compare:\n{rule1}\n{rule2}"
    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return res.choices[0].message.content
