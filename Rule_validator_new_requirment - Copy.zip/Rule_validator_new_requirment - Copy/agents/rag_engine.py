import faiss
import numpy as np
from utils.embeddings import get_embedding
from utils.chunker import chunk_text

class SmartRAG:
    def __init__(self, documents):
        self.chunks = []
        for doc in documents:
            self.chunks.extend(chunk_text(doc))
        self.vectors = [get_embedding(c) for c in self.chunks if c]
        self.index = faiss.IndexFlatL2(len(self.vectors[0]))
        self.index.add(np.array(self.vectors))

    def retrieve(self, query, k=10):
        q_vec = get_embedding(query)
        D, I = self.index.search(np.array([q_vec]), k)
        return [self.chunks[i] for i in I[0]]
