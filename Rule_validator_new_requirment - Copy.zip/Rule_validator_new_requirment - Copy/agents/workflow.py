from langgraph.graph import StateGraph, END

def build_graph(content_fn, synth_fn, match_fn):

    def node_content(state):
        return {**state, "content1": content_fn(state["row"]) }

    def node_synth(state):
        return {**state, "content2": synth_fn(state["content1"], state["chunks"]) }

    def node_match(state):
        return {**state, "result": match_fn(state["content1"], state["content2"]) }

    graph = StateGraph(dict)
    graph.add_node("content", node_content)
    graph.add_node("synth", node_synth)
    graph.add_node("match", node_match)

    graph.set_entry_point("content")
    graph.add_edge("content", "synth")
    graph.add_edge("synth", "match")
    graph.add_edge("match", END)

    return graph.compile()
