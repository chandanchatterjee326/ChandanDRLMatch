from openai import OpenAI
from utils.openai_client import client


def rerank_chunks(query, chunks):
    prompt = f"Select top 3 chunks relevant to: {query}\n{chunks}"
    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    return [res.choices[0].message.content]
