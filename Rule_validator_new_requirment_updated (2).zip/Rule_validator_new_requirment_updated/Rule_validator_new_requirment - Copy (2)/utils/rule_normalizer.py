import re

# ✅ MUST BE AT TOP LEVEL (NO INDENTATION)
def normalize_operator(op):
    if not op:
        return "="

    op = str(op).lower().strip()
    op = re.sub(r"\s+", " ", op)

    if "greater than or equal" in op or ">=" in op:
        return ">="
    if "less than or equal" in op or "<=" in op:
        return "<="
    if "greater than" in op or "greaterthan" in op or "above" in op:
        return ">"
    if "less than" in op or "lessthan" in op or "below" in op:
        return "<"
    if "not equal" in op or "!=" in op:
        return "!="
    if "equal" in op or "equals" in op or "==" in op:
        return "="

    return op


def normalize_text(text):
    if text is None:
        return ""
    return str(text).lower().replace("_", "").strip()


def normalize_value(val):
    if val is None:
        return ""

    val = str(val).lower().strip()

    synonyms = {
        "yes": "true",
        "no": "false",
        "non-smoker": "false",
        "smoker": "true",
        "true": "true",
        "false": "false"
    }

    return synonyms.get(val, val)


def normalize_rule(rule):

    normalized_conditions = []

    for c in rule.get("conditions", []):

        if not isinstance(c, dict):
            continue

        normalized_conditions.append({
            "field": normalize_text(c.get("field")),
            "operator": normalize_operator(c.get("operator")),
            "value": normalize_value(c.get("value"))
        })

    action = normalize_text(rule.get("action", ""))

    return {
        "conditions": normalized_conditions,
        "action": action
    }