from utils.openai_client import client
import json
from utils.json_parser import safe_json_parse
from utils.rule_normalizer import normalize_rule


def strict_compare(rule1, rule2):
    """
    Strict comparison:
    - All conditions must match
    - No missing / extra conditions
    """

    cond1 = rule1.get("conditions", [])
    cond2 = rule2.get("conditions", [])

    if len(cond1) != len(cond2):
        return False, "Number of conditions do not match"

    matched = 0

    for c1 in cond1:
        found = False

        for c2 in cond2:
            if (
                c1.get("field") == c2.get("field") and
                c1.get("operator") == c2.get("operator") and
                str(c1.get("value")) == str(c2.get("value"))
            ):
                found = True
                break

        if found:
            matched += 1
        else:
            return False, f"Condition mismatch for field: {c1.get('field')}"

    # also compare action
    if rule1.get("action") != rule2.get("action"):
        return False, "Action mismatch"

    return True, "All conditions and action match"


def smart_match(rule1, rule2):

    # Normalize rules
    rule1_norm = normalize_rule(rule1)
    rule2_norm = normalize_rule(rule2)

    # 🔥 STEP 1: STRICT LOGIC FIRST (OVERRIDE LLM)
    is_match, strict_reason = strict_compare(rule1_norm, rule2_norm)

    if is_match:
        return {
            "flag": "MATCH",
            "confidence": 1.0,
            "reason": strict_reason,
            "details": []
        }

    # 🔥 STEP 2: LLM ONLY FOR EXPLANATION (NOT DECISION)
    prompt = f"""
Explain why these two rules do NOT match.

Rule1:
{rule1_norm}

Rule2:
{rule2_norm}

Focus on:
- Missing conditions
- Different values
- Different operators
- Action mismatch

Return JSON:

{{
  "reason": "Clear explanation",
  "details": [
    {{
      "field": "...",
      "issue": "missing/mismatch"
    }}
  ]
}}
"""

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.2
    )

    response_text = res.choices[0].message.content
    out = safe_json_parse(response_text)

    if "error" in out:
        return {
            "flag": "MISMATCH",
            "confidence": 0.5,
            "reason": strict_reason,
            "details": []
        }

    return {
        "flag": "MISMATCH",
        "confidence": 0.5,
        "reason": out.get("reason", strict_reason),
        "details": out.get("details", [])
    }