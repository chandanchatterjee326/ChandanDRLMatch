from utils.openai_client import client
import json
from utils.json_parser import safe_json_parse

def synthesize_content(content1, chunks):


    prompt = f"""

    You are a senior business analyst.

    Given:
    Rule to validate:
    {content1}

    Evidence from documents:
    {chunks}

    Task:
    - Identify matching business logic
    - Combine multiple chunks if needed
    - Reconstruct FULL rule

    IMPORTANT:
    - Extract ALL conditions explicitly (do NOT summarize)
    - Each condition must be separate
    - Do NOT merge multiple conditions into one line
    - Use structured format

    Return JSON:

    {{
    "business_content": "...",

    "rule": {{
        "conditions": [
        {{"field": "Age", "operator": ">", "value": "60"}},
        {{"field": "Income", "operator": "<", "value": "5L"}}
        ],
        "action": "..."
    }},

    "confidence": 0-1
    }}
    """

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":prompt}],
        temperature=0.3
    )

    response_text = res.choices[0].message.content

    out = safe_json_parse(response_text)

    if "error" in out:
        return {
            "business_content": "No rule found",
            "rule": {"conditions": [], "action": "Unknown"}
        }

    return out