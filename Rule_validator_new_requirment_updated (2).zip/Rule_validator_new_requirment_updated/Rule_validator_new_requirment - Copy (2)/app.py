import streamlit as st
import pandas as pd
from agents.rag_engine import SmartRAG
from agents.content_generator import generate_content_and_rule
from agents.content_synthesizer import synthesize_content
from agents.matcher import smart_match
from agents.workflow import build_graph
from utils.file_loader import load_documents
from concurrent.futures import ThreadPoolExecutor
from utils.rule_formatter import format_rule
import sys
import os
import json

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
st.title("DRL–DMN Matcher (Business Output)")

file = st.file_uploader("Upload Excel")
folder = st.text_input("Docs folder path")

if st.button("Run"):
    df = pd.read_excel(file)
    docs = load_documents(folder)
    rag = SmartRAG(docs)

    graph = build_graph(generate_content_and_rule, synthesize_content, smart_match)

    def process(i, row):
        query = " ".join([str(v) for v in row.to_dict().values()])
        chunks = rag.retrieve(query)

        state = {
            "row": row.to_dict(),
            "chunks": chunks
        }

        result = graph.invoke(state)

        return {
        "Row ID": i,
        "Business Content 1": result["bc1"],
        "Rule 1": format_rule(result["rule1"]),
        "Business Content 2": result["bc2"],
        "Rule 2": format_rule(result["rule2"]),
        "Flag": result["match"]["flag"],
        "Reason": result["match"]["reason"]
        }

    with ThreadPoolExecutor(max_workers=8) as ex:
        results = list(ex.map(lambda x: process(x[0], x[1]), df.iterrows()))

    st.dataframe(pd.DataFrame(results))
