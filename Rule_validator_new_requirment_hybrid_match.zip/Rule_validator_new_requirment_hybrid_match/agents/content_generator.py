from utils.openai_client import client
import json
from utils.json_parser import safe_json_parse


def generate_content_and_rule(row):
    
    prompt = f"""
You are a business analyst.

Convert the following row into:
1. Business content (clear English)
2. Structured rule

Row:
{row}

IMPORTANT:
- Do NOT drop any column
- Use consistent field names (Age, Income, Policy Type, Credit Score, etc.)
- Do NOT shorten values (e.g., "Life" → "Life Insurance" if context suggests)
- Keep ALL conditions

Return ONLY valid JSON:

{{
  "business_content": "...",
  "rule": {{
    "conditions": [
      {{"field": "...", "operator": "...", "value": "..."}}
    ],
    "action": "..."
  }}
}}
"""

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":prompt}],
        temperature=0.2
    )

    response_text = res.choices[0].message.content

    out = safe_json_parse(response_text)

    if "error" in out:
        return {
            "business_content": "Parsing failed",
            "rule": {"conditions": [], "action": "Unknown"}
        }

    return out