from utils.openai_client import client
import json
from utils.json_parser import safe_json_parse

def synthesize_content(content1, chunks):


    prompt = f"""
    You are a senior business analyst.

    Given:
    Rule to validate:
    {content1}

    Evidence from documents:
    {chunks}

    Task:
    Reconstruct FULL structured rule.

    IMPORTANT:
    - Extract ALL conditions explicitly
    - Each condition must be separate
    - DO NOT summarize into one line
    - DO NOT return sentences in conditions
    - Always return structured JSON

    STRICT FORMAT:

    {{
    "business_content": "...",
    "rule": {{
        "conditions": [
        {{"field": "...", "operator": "...", "value": "..."}}
        ],
        "action": "..."
    }}
    }}
    """

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role":"user","content":prompt}],
        temperature=0.3
    )

    response_text = res.choices[0].message.content

    out = safe_json_parse(response_text)

    if "error" in out:
        return {
            "business_content": "No rule found",
            "rule": {"conditions": [], "action": "Unknown"}
        }

    return out