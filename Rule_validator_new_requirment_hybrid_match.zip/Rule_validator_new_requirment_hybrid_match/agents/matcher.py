from utils.openai_client import client
from utils.rule_normalizer import normalize_rule
from utils.mapping import FIELD_SYNONYMS, VALUE_SYNONYMS, STATE_MAP, OPERATOR_RULES
from utils.auto_mapper import learn_from_llm
from datetime import datetime
import ast
import json


# -----------------------------
# 🔥 NORMALIZERS
# -----------------------------
def normalize_str(val):
    if val is None:
        return ""
    return str(val).lower().strip()


def normalize_state(val):
    val = normalize_str(val)
    return STATE_MAP.get(val, val)


# -----------------------------
# 🔥 HELPERS
# -----------------------------
def parse_date(val):
    try:
        return datetime.strptime(val, "%Y-%m-%d")
    except:
        return None


def parse_list(val):
    try:
        if isinstance(val, str) and "[" in val:
            return ast.literal_eval(val)
    except:
        return None
    return None


def extract_range(val):
    val = normalize_str(val)

    if "between" in val and "and" in val:
        parts = val.replace("between", "").split("and")
        try:
            return int(parts[0].strip()), int(parts[1].strip())
        except:
            return None

    return None


# -----------------------------
# 🔥 FIELD MATCH
# -----------------------------
def field_match(f1, f2):
    f1 = normalize_str(f1)
    f2 = normalize_str(f2)

    if f1 == f2:
        return True

    for key, values in FIELD_SYNONYMS.items():
        if f1 == key and f2 in values:
            return True
        if f2 == key and f1 in values:
            return True

    if f1 in f2 or f2 in f1:
        return True

    return False


# -----------------------------
# 🔥 VALUE MATCH (CORE LOGIC)
# -----------------------------
def value_match(v1, v2):
    v1 = normalize_str(v1)
    v2 = normalize_str(v2)

    # 🔥 RANGE MATCH
    r1 = extract_range(v1)
    r2 = extract_range(v2)
    if r1 and r2:
        return r1 == r2

    # 🔥 LIST MATCH
    l1 = parse_list(v1)
    l2 = parse_list(v2)

    if l1 and l2:
        return set(l1) == set(l2)

    if l2 and v1 in l2:
        return True
    if l1 and v2 in l1:
        return True

    # 🔥 STATE MATCH
    v1 = normalize_state(v1)
    v2 = normalize_state(v2)

    # EXACT
    if v1 == v2:
        return True

    # SYNONYM
    for key, values in VALUE_SYNONYMS.items():
        if v1 == key and v2 in values:
            return True
        if v2 == key and v1 in values:
            return True

    # PARTIAL
    if v1 in v2 or v2 in v1:
        return True

    return False


# -----------------------------
# 🔥 CONDITION MATCH
# -----------------------------
def condition_match(c1, c2):

    # FIELD
    if not field_match(c1.get("field"), c2.get("field")):
        return False

    op1 = normalize_str(c1.get("operator"))
    op2 = normalize_str(c2.get("operator"))

    v1 = normalize_str(c1.get("value"))
    v2 = normalize_str(c2.get("value"))

    d1 = parse_date(v1)
    d2 = parse_date(v2)

    # 🔥 DATE LOGIC
    if d1 and d2:
        if op1 == ">=" and op2 == "=":
            if d2 < d1:
                return False
        elif op1 == "<=" and op2 == "=":
            if d2 > d1:
                return False
        elif op1 != op2:
            return False
    else:
        if op1 != op2:
            if not (op1 in OPERATOR_RULES and op2 in OPERATOR_RULES[op1]):
                pass  # allow flexible

    # VALUE
    return value_match(v1, v2)


# -----------------------------
# 🔥 SCORE ENGINE
# -----------------------------
def calculate_match_score(rule1, rule2):

    cond1 = rule1.get("conditions", [])
    cond2 = rule2.get("conditions", [])

    if not cond1 or not cond2:
        return 0.0

    match_count = 0

    for c1 in cond1:
        for c2 in cond2:
            if condition_match(c1, c2):
                match_count += 1
                break

    return match_count / len(cond1)


# -----------------------------
# 🔥 LLM FALLBACK
# -----------------------------
def llm_decide(rule1, rule2):

    prompt = f"""
You are an expert business rule validator.

Determine if BOTH rules represent SAME BUSINESS LOGIC.

- Ignore naming differences
- Consider semantic meaning
- Consider equivalence

Rule 1:
{rule1}

Rule 2:
{rule2}

Return STRICT JSON:

{{
  "decision": "MATCH or MISMATCH",
  "reason": "clear explanation"
}}
"""

    res = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )

    text = res.choices[0].message.content

    try:
        return json.loads(text)
    except:
        return {"decision": "MISMATCH", "reason": "LLM parse error"}


# -----------------------------
# 🔥 MAIN FUNCTION
# -----------------------------
def smart_match(rule1, rule2):

    rule1_norm = normalize_rule(rule1)
    rule2_norm = normalize_rule(rule2)

    cond1 = rule1_norm.get("conditions", [])
    cond2 = rule2_norm.get("conditions", [])

    match_details = []
    match_count = 0

    # 🔥 CONDITION LEVEL MATCH TRACKING
    for c1 in cond1:
        matched = False

        for c2 in cond2:
            if condition_match(c1, c2):
                matched = True
                match_count += 1

                match_details.append({
                    "field": c1.get("field"),
                    "rule1_value": c1.get("value"),
                    "rule2_value": c2.get("value"),
                    "status": "MATCH"
                })
                break

        if not matched:
            match_details.append({
                "field": c1.get("field"),
                "rule1_value": c1.get("value"),
                "rule2_value": None,
                "status": "MISMATCH"
            })

    score = match_count / len(cond1) if cond1 else 0

    # ✅ STRONG MATCH
    if score >= 0.75:
        return {
            "flag": "MATCH",
            "confidence": score,
            "reason": f"{match_count}/{len(cond1)} conditions matched",
            "details": match_details
        }

    # ❌ STRONG MISMATCH
    if score <= 0.3:
        return {
            "flag": "MISMATCH",
            "confidence": score,
            "reason": f"Only {match_count}/{len(cond1)} conditions matched",
            "details": match_details
        }

    # 🤖 LLM FALLBACK
    llm_result = llm_decide(rule1_norm, rule2_norm)
    field_map, value_map = learn_from_llm(rule1_norm, rule2_norm, llm_result.get("decision"))

    print("AUTO LEARN FIELD:", field_map)
    print("AUTO LEARN VALUE:", value_map)

    return {
        "flag": llm_result.get("decision", "MISMATCH"),
        "confidence": score,
        "reason": llm_result.get("reason"),
        "details": match_details
    }