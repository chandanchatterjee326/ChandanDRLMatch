from langgraph.graph import StateGraph, END


def build_graph(gen_fn, synth_fn, match_fn):

    def node_gen(state):
        out = gen_fn(state["row"])
        return {**state, "bc1": out["business_content"], "rule1": out["rule"]}
    
    def node_synth(state):
        out = synth_fn(state["bc1"], state["chunks"])
        return {**state, "bc2": out["business_content"], "rule2": out["rule"]}
    
    def node_match(state):
        result = match_fn(state["rule1"], state["rule2"])
        return {**state, "match": result}

    graph = StateGraph(dict)
    graph.add_node("gen", node_gen)
    graph.add_node("synth", node_synth)
    graph.add_node("match", node_match)

    graph.set_entry_point("gen")
    graph.add_edge("gen","synth")
    graph.add_edge("synth","match")
    graph.add_edge("match",END)

    return graph.compile()
