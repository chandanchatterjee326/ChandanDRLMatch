# 🔥 FIELD SYNONYMS

FIELD_SYNONYMS = {
    "doctor care": ["under regular care", "under physician care"],
    "currently working": ["employment status", "working status"],
    "work ability": ["ability to perform duties", "abilitytoperformduties"],
    "working hours": ["hours worked", "hours worked per week"],
    "state": ["residence state", "home state", "living state"] ,     
    "requirement type": ["notification type"],
    "trigger event": ["benefit type"],
    "effective date": ["effective_date"],
    "state": ["jurisdiction"]
}


# 🔥 VALUE SYNONYMS
VALUE_SYNONYMS = {
    "true": ["yes", "under regular care", "eligible"],
    "false": ["no", "not working", "inactive"],
    "unable to perform duties": ["unable", "cannot work"],     
    "initial notification": ["notice of claim"],
    "start of disability": ["disability"],
}


# 🔥 STATE NORMALIZATION
STATE_MAP = {
    "al": "alabama",
    "ak": "alaska",
    "az": "arizona",
    "ar": "arkansas",
    "ca": "california",
    "co": "colorado",
    "ct": "connecticut",
    "de": "delaware",
    "fl": "florida",
    "ga": "georgia",
    "hi": "hawaii",
    "id": "idaho",
    "il": "illinois",
    "in": "indiana",
    "ia": "iowa",
    "ks": "kansas",
    "ky": "kentucky",
    "la": "louisiana",
    "me": "maine",
    "md": "maryland",
    "ma": "massachusetts",
    "mi": "michigan",
    "mn": "minnesota",
    "ms": "mississippi",
    "mo": "missouri",
    "mt": "montana",
    "ne": "nebraska",
    "nv": "nevada",
    "nh": "new hampshire",
    "nj": "new jersey",
    "nm": "new mexico",
    "ny": "new york",
    "nc": "north carolina",
    "nd": "north dakota",
    "oh": "ohio",
    "ok": "oklahoma",
    "or": "oregon",
    "pa": "pennsylvania",
    "ri": "rhode island",
    "sc": "south carolina",
    "sd": "south dakota",
    "tn": "tennessee",
    "tx": "texas",
    "ut": "utah",
    "vt": "vermont",
    "va": "virginia",
    "wa": "washington",
    "wv": "west virginia",
    "wi": "wisconsin",
    "wy": "wyoming",
    "dc": "district of columbia"
}


# 🔥 OPERATOR FLEXIBILITY RULES
OPERATOR_RULES = {
    ">=": ["="],   # = satisfies >=
    "<=": ["="]
}