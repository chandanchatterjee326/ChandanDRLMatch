import os
from PyPDF2 import PdfReader
import docx

def load_documents(folder_path):
    texts = []
    for file in os.listdir(folder_path):
        path = os.path.join(folder_path, file)
        if file.endswith(".pdf"):
            reader = PdfReader(path)
            for page in reader.pages:
                txt = page.extract_text()
                if txt:
                    texts.append(txt)
        elif file.endswith(".docx"):
            doc = docx.Document(path)
            texts.append("\n".join([p.text for p in doc.paragraphs]))
        elif file.endswith(".txt"):
            with open(path, "r", encoding="utf-8") as f:
                texts.append(f.read())
    return texts
