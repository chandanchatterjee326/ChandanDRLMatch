import re

# from tomlkit import value

# ✅ MUST BE AT TOP LEVEL (NO INDENTATION)
def normalize_operator(op):
    if not op:
        return "="

    op = str(op).lower().strip()
    op = re.sub(r"\s+", " ", op)

    if "greater than or equal" in op or ">=" in op:
        return ">="
    if "less than or equal" in op or "<=" in op:
        return "<="
    if "greater than" in op or "greaterthan" in op or "above" in op:
        return ">"
    if "less than" in op or "lessthan" in op or "below" in op:
        return "<"
    if "not equal" in op or "!=" in op:
        return "!="
    if "equal" in op or "equals" in op or "==" in op:
        return "="

    return op


def normalize_text(text):
    if text is None:
        return ""

    text = str(text).lower().strip()

    # 🔥 HANDLE NAN PROPERLY
    if text in ["nan", "none", ""]:
        return ""

    text = text.replace("_", " ")
    text = " ".join(text.split())

    return text


def normalize_value(val):
    if val is None:
        return ""

    val = str(val).lower().strip()

    # 🔥 HANDLE NAN
    if val in ["nan", "none", ""]:
        return ""

    synonyms = {
        "yes": "true",
        "no": "false",
        "true": "true",
        "false": "false"
    }

    return synonyms.get(val, val)

def normalize_rule(rule):

    normalized_conditions = []

    for c in rule.get("conditions", []):

        if not isinstance(c, dict):
            continue

        field = normalize_text(c.get("field"))
        value = normalize_value(c.get("value"))

        # 🔥 SKIP EMPTY CONDITIONS
        if not field or not value:
            continue

        normalized_conditions.append({
            "field": field,
            "operator": normalize_operator(c.get("operator")),
            "value": value
        })

    action = normalize_text(rule.get("action", ""))

    return {
        "conditions": normalized_conditions,
        "action": action
    }