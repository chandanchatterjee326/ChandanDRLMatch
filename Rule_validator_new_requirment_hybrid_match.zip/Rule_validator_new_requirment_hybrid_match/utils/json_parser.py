import json
import re

def safe_json_parse(text):
    try:
        if not text:
            return {"error": "Empty response", "raw": text}

        # Extract JSON block
        match = re.search(r"\{.*\}", text, re.DOTALL)

        if not match:
            return {"error": "No JSON found", "raw": text}

        return json.loads(match.group())

    except Exception as e:
        return {"error": str(e), "raw": text}