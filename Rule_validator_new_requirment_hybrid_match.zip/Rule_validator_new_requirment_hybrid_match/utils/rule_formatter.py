from utils.rule_normalizer import normalize_operator

def format_rule(rule):
    try:
        conditions = rule.get("conditions", [])
        action = rule.get("action", "")

        lines = []

        for c in conditions:
            field = c.get("field", "")
            op = normalize_operator(c.get("operator", ""))
            value = c.get("value", "")

            # Normalize operators to a standard format           
            operator_map = {
                "==": "=",
                "equals": "=",
                "=": "=",
                "greater_than": ">",
                ">": ">",
                "less_than": "<",
                "<": "<"
            }

            op = operator_map.get(str(op).lower(), op)    

            lines.append(f"{field}{op}{value}")

        lines.append(f"Action={action}")

        return "\n".join(lines)

    except Exception as e:
        return f"Formatting error: {str(e)}"