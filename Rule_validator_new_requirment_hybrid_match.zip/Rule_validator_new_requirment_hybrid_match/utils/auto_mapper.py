from collections import defaultdict


def learn_from_llm(rule1, rule2, decision):

    field_map = defaultdict(set)
    value_map = defaultdict(set)

    cond1 = rule1.get("conditions", [])
    cond2 = rule2.get("conditions", [])

    if decision != "MATCH":
        return {}, {}

    for c1 in cond1:
        for c2 in cond2:

            f1 = str(c1.get("field")).lower()
            f2 = str(c2.get("field")).lower()

            v1 = str(c1.get("value")).lower()
            v2 = str(c2.get("value")).lower()

            # 🔥 FIELD LEARNING
            if f1 != f2 and (f1 in f2 or f2 in f1):
                field_map[f1].add(f2)

            # 🔥 VALUE LEARNING
            if v1 != v2 and (v1 in v2 or v2 in v1):
                value_map[v1].add(v2)

    return field_map, value_map