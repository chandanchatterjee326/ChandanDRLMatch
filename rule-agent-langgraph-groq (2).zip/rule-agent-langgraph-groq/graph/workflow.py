from langgraph.graph import StateGraph, END
from agents.extract_agent import extract_agent
from agents.drl_agent import drl_agent
from agents.validation_agent import validation_agent
from typing import TypedDict, List, Dict
from agents.dmn_agent import dmn_agent
from agents.matcher_agent import matcher_agent
from agents.dmn_agent import dmn_agent
from agents.matcher_agent import matcher_agent

class AgentState(TypedDict):
    df: any
    rules: List
    extracted_rules: List
    drl_rules: List
    valid: bool
    dmn_rules: str      
    results: list  

def build_graph():
    builder = StateGraph(AgentState)

    builder.add_node("extract", extract_agent)
    builder.add_node("generate", drl_agent)
    builder.add_node("validate", validation_agent)
    builder.add_node("dmn", dmn_agent)
    builder.add_node("match", matcher_agent)  
    

    builder.set_entry_point("extract")

    builder.add_edge("extract", "generate")
    builder.add_edge("generate", "validate")    
    builder.add_edge("validate", "dmn")
    builder.add_edge("dmn", "match")
    builder.add_edge("match", END)
    builder.add_edge("validate", END)
         
    
    

    return builder.compile()