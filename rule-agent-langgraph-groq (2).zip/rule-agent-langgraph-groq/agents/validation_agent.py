from config import get_llm

def validation_agent(state):
    llm = get_llm()
    drl_rules = state["drl_rules"]

    prompt = f"""
    Validate the following DRL JSON:

    {drl_rules}

    Fix if invalid and return JSON only.
    """

    response = llm.invoke(prompt)
    output = response.content if hasattr(response, "content") else response

    return {"drl_rules": [output],
            "valid": "error" not in output.lower()}