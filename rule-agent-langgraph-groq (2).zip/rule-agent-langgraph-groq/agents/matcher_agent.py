
from config import get_llm

def matcher_agent(state):
    llm=get_llm()
    res=[]
    dmn_rules = state.get("dmn_rules", "No DMN rules found")
    for d in state["drl_rules"]:
        response = llm.invoke(
            f"""Compare these two JSON rules:
            DRL: {d}
            DMN: {dmn_rules}

            Return ONLY one word:
            MATCHED or MISMATCH"""
            )
        output = response.content if hasattr(response, "content") else response
        res.append(output)
    return {"results":res}
