def extract_agent(state):
    df = state["df"]
    rules = state["rules"]

    if not rules:
        return {"extracted_rules": []}

    rows = df[df["Rule Name"].isin(rules)].to_dict(orient="records")
    print("Extracted rows:", rows)

    return {"extracted_rules": rows}