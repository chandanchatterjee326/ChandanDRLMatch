import os

def _load_provider(provider):
    # 🔵 GROQ
    if provider == "groq":
        from langchain_groq import ChatGroq

        return ChatGroq(
            groq_api_key=os.getenv("GORQ_API_KEY"),
            model="mixtral-8x7b-32768",
            temperature=0
        )

    # 🟢 OPENAI
    elif provider == "openai":
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            api_key=os.getenv("OPENAI_API_KEY"),
            model="gpt-4o-mini",
            temperature=0
        )

    # 🟡 GEMINI
    elif provider == "gemini":
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            google_api_key=os.getenv("GEMINI_API_KEY"),
            model="gemini-1.5-flash",
            temperature=0
        )
    # 🟣 Ollama
    elif provider == "ollama":
        from langchain_community.chat_models import ChatOllama

        return ChatOllama(
            model="phi3-mini",   # or llama3
            temperature=0,
            num_predict=128
        )    

    # 🟣 HUGGING FACE
    elif provider == "huggingface":
        from huggingface_hub import InferenceClient

        client = InferenceClient(
            token=os.getenv("HUGGINGFACE_API_KEY")
        )

        class HuggingFaceWrapper:
            def invoke(self, prompt):
                response = client.chat_completion(
                    messages=[
                    {"role": "user", "content": prompt}
                ],
                    model="mistralai/Mistral-7B-Instruct-v0.2",
                    max_tokens=512
                )
                return response.choices[0].message["content"]  # string

        return HuggingFaceWrapper()
    else:
        raise ValueError(f"Unsupported provider: {provider}")


def get_llm():
    # providers = ["groq","ollama", "gemini","huggingface"]
    providers = ["openai"]

    for provider in providers:
        try:
            llm = _load_provider(provider)

            # 🔥 test call
            response = llm.invoke("Hello")

            # normalize check
            if hasattr(response, "content"):
                _ = response.content
            else:
                _ = response

            print(f"✅ Using provider: {provider}")
            return llm

        except Exception as e:
            print(f"❌ {provider} failed → {e}")
            continue

    raise Exception("❌ No working LLM provider found")