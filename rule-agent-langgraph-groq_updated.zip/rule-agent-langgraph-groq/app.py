import streamlit as st
import pandas as pd
from graph.workflow import build_graph
from dotenv import load_dotenv
import os
import json

load_dotenv()

df = pd.read_excel("data/rules.xlsx")

rules = st.multiselect("Select Rules", df["Rule Name"].unique())

uploaded_drl = st.file_uploader("Upload DRL File (Excel/CSV)", type=["xlsx", "csv"])

uploaded_dmn_files = st.file_uploader(
    "Upload DMN Documents (PDF/Word/Email)",
    type=["pdf", "docx", "eml"],
    accept_multiple_files=True
)

user_prompt = st.text_input("Enter your request (e.g., check loan approval rule)")

st.write(f"Using LLM Provider: {os.getenv('LLM_PROVIDER')}")
graph = build_graph()

if st.button("Run"):
    result = graph.invoke({
        "drl_file": uploaded_drl,
        "dmn_files": uploaded_dmn_files,
        "user_prompt": user_prompt,
        "df": df,
        "rules": rules
    })

    # st.write(result["drl_rules"])
    drl = result.get("drl_rules", [])

    if drl:
        try:
            parsed = drl[0] if isinstance(drl, list) else drl
            if isinstance(parsed, str):
                parsed = json.loads(parsed)
            st.json(parsed)
        except:
            st.write(parsed)
    st.subheader("📗 DMN Rules")
    st.write(result.get("dmn_rules"))
    
    