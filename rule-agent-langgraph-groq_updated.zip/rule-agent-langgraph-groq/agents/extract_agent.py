def extract_agent(state):
    df = state.get("df")
    rules = state.get("rules")

    if not df or not rules:
        return {"extracted_rules": []}

    rows = df[df["Rule Name"].isin(rules)].to_dict(orient="records")
    print("Extracted rows:", rows)

    return {"extracted_rules": rows}