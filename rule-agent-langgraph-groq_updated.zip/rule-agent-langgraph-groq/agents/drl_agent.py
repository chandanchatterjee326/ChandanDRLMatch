import json

from config import get_llm

def drl_agent(state):    
    llm = get_llm()

    # Filter relevant rows
    rows = state["drl_data"]

    if not rows:
        return {"drl_rules": ["No matching rules found"]}

    prompt = f"""
    You are a Drools (DRL) expert.

    Convert the following business rules into DRL-style JSON.

    Each rule must include:
    - rule_name
    - conditions (LOB, State, Increase %)
    - action

    Rules:
    {rows}

    Return ONLY valid JSON in this format:

    [
    {{
        "rule_name": "...",
        "conditions": {{
        "LOB": "...",
        "State": "...",
        "Increase %": "..."
        }},
        "action": "..."
    }}
    ]

    Do not include markdown or explanations.
    """

    try:
        response = llm.invoke(prompt)
        output = response.content if hasattr(response, "content") else response

        try:
            parsed = json.loads(output)
        except:
            parsed = output

        return {"drl_rules": [parsed]}

    except Exception as e:
        return {"drl_rules": [f"Error: {str(e)}"]}