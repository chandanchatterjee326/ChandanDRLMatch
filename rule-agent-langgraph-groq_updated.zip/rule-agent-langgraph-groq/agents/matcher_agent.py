import json
from config import get_llm

def matcher_agent(state):
    llm = get_llm()
    res = []
    dmn_rules = state.get("dmn_rules", "No DMN rules found")

    if isinstance(dmn_rules, (dict, list)):
        dmn_rules = json.dumps(dmn_rules)

    for d in state.get("drl_rules", []):
        drl_text = json.dumps(d) if isinstance(d, (dict, list)) else str(d)
        response = llm.invoke(
            f"""Compare these two JSON rules:
            DRL: {drl_text}
            DMN: {dmn_rules}

            Return ONLY one word:
            MATCHED or MISMATCH"""
        )
        output = response.content if hasattr(response, "content") else response
        res.append(str(output).strip())

    return {"results": res}
