import json
from config import get_llm

def dmn_agent(state):
    llm = get_llm()
    text = state.get("dmn_text")

    if not text:
        try:
            with open("data/dmn_docs/rules.txt", "r", encoding="utf-8") as f:
                text = f.read()
        except Exception as e:
            return {"dmn_rules": f"Error reading file: {str(e)}"}

    # ✅ Step 2: Proper prompt
    prompt = f"""
    You are a rule extraction expert.

    Extract rules into STRICT JSON format.

    Return ONLY JSON in this structure:

    {{
    "rules": [
        {{
        "state": "...",
        "violation_limit": ...,
        "status": "..."
        }}
    ]
    }}

    IMPORTANT:
    - Use a LIST [] not numbered keys
    - Do NOT use 0:, 1:, etc.
    - Do NOT include explanations
    - Do NOT include markdown


    Input:
    {text}

    Return ONLY valid JSON.
    No explanations.
    No markdown.
    """

    try:
        # ✅ Step 3: Call LLM
        response = llm.invoke(prompt)

        output = response.content if hasattr(response, "content") else response

        # ✅ Step 4: Try parsing JSON
        try:
            parsed = json.loads(output)
        except:
            parsed = output

        return {"dmn_rules": parsed}

    except Exception as e:
        return {"dmn_rules": f"LLM Error: {str(e)}"}