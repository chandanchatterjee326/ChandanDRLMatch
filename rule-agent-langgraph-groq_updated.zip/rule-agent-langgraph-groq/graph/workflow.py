from agents.main_agent import main_agent
from agents.drl_loader_agent import drl_loader_agent
from agents.dmn_loader_agent import dmn_loader_agent
from agents.extract_agent import extract_agent
from agents.drl_agent import drl_agent
from agents.validation_agent import validation_agent
from agents.dmn_agent import dmn_agent
from agents.matcher_agent import matcher_agent
from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Any

class AgentState(TypedDict, total=False):
    df: any
    rules: List
    extracted_rules: List
    drl_rules: List
    valid: bool
    dmn_rules: Any
    results: List
    drl_file: Any
    dmn_files: List
    user_prompt: str

    drl_data: List
    dmn_text: str

def build_graph():
    builder = StateGraph(AgentState)

    builder.add_node("main", main_agent)
    builder.add_node("drl_loader", drl_loader_agent)
    builder.add_node("dmn_loader", dmn_loader_agent)
    builder.add_node("extract", extract_agent)
    builder.add_node("generate", drl_agent)
    builder.add_node("validate", validation_agent)
    builder.add_node("dmn", dmn_agent)
    builder.add_node("match", matcher_agent)  
    

    builder.set_entry_point("main")

    builder.add_edge("main", "drl_loader")
    builder.add_edge("drl_loader", "dmn_loader")
    builder.add_edge("dmn_loader", "extract")
    builder.add_edge("extract", "generate")
    builder.add_edge("generate", "validate")
    builder.add_edge("validate", "dmn")
    builder.add_edge("dmn", "match")
    builder.add_edge("match", END)
    builder.add_edge("validate", END)
         
    
    

    return builder.compile()