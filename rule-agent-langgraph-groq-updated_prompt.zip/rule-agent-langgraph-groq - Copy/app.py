import streamlit as st
import pandas as pd
from graph.workflow import build_graph

st.title("Enterprise Rule Validator")

uploaded_drl = st.file_uploader("Upload DRL (Excel)", type=["xlsx", "csv"])
uploaded_dmn = st.file_uploader("Upload DMN Docs", type=["pdf", "docx"], accept_multiple_files=True)

user_prompt = st.text_input("Enter your request")

if st.button("Run"):

    if not uploaded_drl or not uploaded_dmn or not user_prompt:
        st.error("Upload DRL, DMN and enter prompt")
        st.stop()

    # Read DRL
    if uploaded_drl.name.endswith(".xlsx"):
        df = pd.read_excel(uploaded_drl)
    else:
        df = pd.read_csv(uploaded_drl)

    graph = build_graph()   # ✅ moved here

    with st.spinner("Processing..."):

        
        result = graph.invoke({

            "drl_data": df.to_dict(orient="records"),
            "dmn_files": list(uploaded_dmn),   # ✅ FORCE LIST
            "user_prompt": user_prompt
})

    # Safety check
    if "results" not in result:
        st.error("Processing failed. Check logs.")
        st.write(result)
        st.stop()

    st.success("✅ Completed")

    results_df = pd.DataFrame(result["results"])
    st.dataframe(results_df)

    st.write("### Summary")
    st.json(result.get("summary", {}))

    # Debug (optional)
    # st.write("DEBUG:", result)