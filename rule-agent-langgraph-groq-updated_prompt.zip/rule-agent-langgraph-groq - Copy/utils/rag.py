from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from langchain_openai import OpenAIEmbeddings

def create_vector_db(text):

    if not text or text.strip() == "":
        print("⚠️ Empty DMN text")
        return None

    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200
    )

    chunks = splitter.split_text(text)

    if not chunks:
        print("⚠️ No chunks created")
        return None

    embeddings = OpenAIEmbeddings()
    db = FAISS.from_texts(chunks, embeddings)

    return db


def retrieve_context(db, query):
    if db is None:
        return ""

    docs = db.similarity_search(query, k=3)
    return "\n".join([d.page_content for d in docs])