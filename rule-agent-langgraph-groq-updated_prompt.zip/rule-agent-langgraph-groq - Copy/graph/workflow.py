from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Dict, Any

from agents.intent_agent import intent_agent
from agents.drl_loader import drl_loader
from agents.dmn_loader_agent import dmn_loader
from agents.drl_agent import drl_agent
from agents.dmn_agent import dmn_agent
from agents.rag_agent import rag_agent   # ✅ ADD THIS
from agents.matcher_agent import matcher_agent
from agents.decesion_agent import decision_agent



class AgentState(TypedDict):
    user_prompt: str
    drl_data: Any
    dmn_files: Any   # ✅ ADD THIS
    intent: Dict
    filtered_drl: List
    dmn_text: str
    dmn_chunks: List
    results: List
    summary: Dict


def build_graph():
    g = StateGraph(dict)

    g.add_node("intent", intent_agent)
    g.add_node("drl_loader", drl_loader)
    g.add_node("dmn_loader", dmn_loader)
    g.add_node("drl_extract", drl_agent)
    g.add_node("dmn_extract", dmn_agent)
    g.add_node("rag", rag_agent)   # ✅ ADD THIS
    g.add_node("match", matcher_agent)
    g.add_node("decision", decision_agent)

    g.set_entry_point("intent")

    g.add_edge("intent", "drl_loader")
    g.add_edge("drl_loader", "dmn_loader")
    g.add_edge("dmn_loader", "drl_extract")
    g.add_edge("drl_extract", "dmn_extract")
    g.add_edge("dmn_extract", "rag")      # ✅ ADD THIS
    g.add_edge("rag", "match")            # ✅ ADD THIS
    g.add_edge("match", "decision")
    g.add_edge("decision", END)

    return g.compile()