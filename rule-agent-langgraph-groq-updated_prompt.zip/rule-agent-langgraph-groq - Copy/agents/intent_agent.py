import re

def intent_agent(state):
    prompt = state.get("user_prompt", "").lower()

    match = re.search(r"(top|first)\s+(\d+)", prompt)

    row_limit = int(match.group(2)) if match else 10   # ✅ FIX

    return {
        **state,   # ✅ CRITICAL FIX
        "intent": {
            "action": "validate",
            "row_limit": row_limit
        }
    }