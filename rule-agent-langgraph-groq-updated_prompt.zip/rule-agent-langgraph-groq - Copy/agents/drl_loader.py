def drl_loader(state):
    drl_data = state.get("drl_data")

    if not drl_data:
        return {**state, "drl_data": []}

    return {
        **state,   # ✅ FIX
        "drl_data": drl_data
    }