def extract_agent(state):
    df = state.get("df")
    rules = state.get("rules")

    if df is None or df.empty or not rules:
        return {**state, "extracted_rules": []}

    rows = df[df["Rule Name"].isin(rules)]
    if rows.empty:
        return {**state, "extracted_rules": []}

    rows = rows.to_dict(orient="records")
    print("Extracted rows:", rows)

    return {
        **state,   # ✅ FIX
        "extracted_rules": rows
    }