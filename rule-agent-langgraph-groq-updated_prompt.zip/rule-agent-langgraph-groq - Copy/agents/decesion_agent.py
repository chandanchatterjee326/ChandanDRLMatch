def decision_agent(state):
    results = state.get("results", [])

    approved = sum(1 for r in results if r.get("match") == "✅")

    return {
        **state,
        "summary": {
            "approved": approved,
            "total": len(results)
        }
    }