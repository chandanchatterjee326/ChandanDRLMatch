def drl_agent(state):
    rows = state.get("drl_data", [])

    limit = state.get("intent", {}).get("row_limit", 10)
    selected_rows = rows[:limit]

    return {
        **state,
        "filtered_drl": selected_rows
    }