from PyPDF2 import PdfReader
import docx

def load_dmn_text(files):
    text = ""

    for file in files:
        if file.name.endswith(".pdf"):
            reader = PdfReader(file)
            for page in reader.pages:
                text += page.extract_text() or ""

        elif file.name.endswith(".docx"):
            doc = docx.Document(file)
            for para in doc.paragraphs:
                text += para.text

    return text


def dmn_loader(state):
    print("DEBUG BEFORE DMN LOADER:", state.keys())

    dmn_text = load_dmn_text(state.get("dmn_files", []))

    return {
        **state,
        "dmn_text": dmn_text
    }