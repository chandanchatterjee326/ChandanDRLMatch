import json
from config import get_llm

def validation_agent(state):
    llm = get_llm()
    drl_rules = state.get("drl_rules", [])

    prompt = f"""
    Validate the following DRL JSON:

    {drl_rules}

    Fix if invalid and return JSON only.
    """

    response = llm.invoke(prompt)
    output = response.content if hasattr(response, "content") else response

    try:
        parsed = json.loads(output)
    except Exception:
        parsed = output

    normalized = parsed if isinstance(parsed, list) else [parsed]
    valid = isinstance(parsed, (list, dict))

    return {
        **state,   # ✅ FIX
        "drl_rules": normalized,
        "valid": valid
    }