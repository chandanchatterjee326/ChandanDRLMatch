def rag_agent(state):
    text = state.get("dmn_text", "")

    if not text:
        return {**state, "dmn_chunks": []}

    # simple chunking (safe fallback)
    chunks = text.split("\n")

    return {
        **state,
        "dmn_chunks": chunks
    }