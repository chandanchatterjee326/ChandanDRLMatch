def matcher_agent(state):
    results = []

    rows = state.get("filtered_drl", [])
    dmn_chunks = state.get("dmn_chunks", [])

    for idx, row in enumerate(rows):
        match = any(str(row).lower() in chunk.lower() for chunk in dmn_chunks)

        results.append({
            "row_id": idx + 1,
            "drl_rule": str(row),
            "match": "✅" if match else "❌",
            "confidence": 0.85 if match else 0.6,
            "reason": "Match found" if match else "No match"
        })

    return {
        **state,
        "results": results
    }