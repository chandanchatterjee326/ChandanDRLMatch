import pandas as pd

def drl_loader_agent(state):
    file = state.get("drl_file")

    if not file:
        return {**state, "drl_data": []}

    if file.name.endswith(".xlsx"):
        df = pd.read_excel(file)
    elif file.name.endswith(".csv"):
        df = pd.read_csv(file)
    else:
        return {**state, "drl_data": []}

    return {
        **state,   # ✅ FIX
        "drl_data": df.to_dict(orient="records")
    }