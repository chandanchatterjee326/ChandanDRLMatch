def main_agent(state):
    return state   # ❌ was returning {} → breaking everything