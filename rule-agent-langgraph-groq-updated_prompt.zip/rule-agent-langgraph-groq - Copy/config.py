import os
from dotenv import load_dotenv

load_dotenv()

_llm_instance = None

def _load_provider(provider):
    #  GROQ
    if provider == 'groq':
        from langchain_groq import ChatGroq

        return ChatGroq(
            groq_api_key=os.getenv('GORQ_API_KEY'),
            model='mixtral-8x7b-32768',
            temperature=0
        )

    #  OPENAI
    elif provider == 'openai':
        from langchain_openai import ChatOpenAI

        return ChatOpenAI(
            api_key=os.getenv('OPENAI_API_KEY'),
            model='gpt-4o-mini',
            temperature=0
        )

    #  GEMINI
    elif provider == 'gemini':
        from langchain_google_genai import ChatGoogleGenerativeAI

        return ChatGoogleGenerativeAI(
            google_api_key=os.getenv('GEMINI_API_KEY'),
            model='gemini-1.5-flash',
            temperature=0
        )
    #  Ollama
    elif provider == 'ollama':
        from langchain_community.chat_models import ChatOllama

        return ChatOllama(
            model='phi3-mini',   # or llama3
            temperature=0,
            num_predict=128
        )    

    #  HUGGING FACE
    elif provider == 'huggingface':
        from huggingface_hub import InferenceClient

        client = InferenceClient(
            token=os.getenv('HUGGINGFACE_API_KEY')
        )

        class HuggingFaceWrapper:
            def invoke(self, prompt):
                response = client.chat_completion(
                    messages=[
                    {'role': 'user', 'content': prompt}
                ],
                    model='mistralai/Mistral-7B-Instruct-v0.2',
                    max_tokens=512
                )
                return response.choices[0].message['content']  # string

        return HuggingFaceWrapper()
    else:
        raise ValueError(f'Unsupported provider: {provider}')


def get_llm():
    global _llm_instance
    if _llm_instance is not None:
        return _llm_instance

    # provider = os.getenv('openai').lower()
    provider = os.getenv("LLM_PROVIDER", "openai").lower()

    try:
        llm = _load_provider(provider)
    except Exception:
        if provider != 'openai':
            llm = _load_provider('openai')
        else:
            raise

    _llm_instance = llm
    print(f' Using provider: {provider}')
    return _llm_instance
