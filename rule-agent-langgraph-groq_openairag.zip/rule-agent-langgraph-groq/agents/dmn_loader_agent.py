from PyPDF2 import PdfReader
import docx
import email
from docx import Document

def read_pdf(file):
    reader = PdfReader(file)
    return " ".join([page.extract_text() for page in reader.pages])



def read_docx(file):
    doc = docx.Document(file)
    return " ".join([p.text for p in doc.paragraphs])

def read_eml(file):
    msg = email.message_from_bytes(file.read())
    return msg.get_payload()

def dmn_loader_agent(state):
    files = state.get("dmn_files") or []
    texts = []

    for f in files:
        if f.name.endswith(".pdf"):
            texts.append(read_pdf(f))
        elif f.name.endswith(".docx"):
            texts.append(read_docx(f))
        elif f.name.endswith(".eml"):
            texts.append(read_eml(f))

    return {"dmn_text": " ".join(texts)}

def dmn_loader(state):
    files = state.get("dmn_files", [])
    full_text = ""

    for f in files:
        if f.name.endswith(".docx"):
            full_text += read_docx(f)

    return {"dmn_text": full_text}