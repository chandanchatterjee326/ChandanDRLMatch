import json

from config import get_llm

def drl_agent(state):    
    llm = get_llm()

    # Filter relevant rows
    rows = state["drl_data"]

    if not rows:
        return {"drl_rules": ["No matching rules found"]}

    prompt = f"""
    Convert this table into business rules JSON.

    {data}

    Return:
    [
      {{
        "conditions": "...",
        "action": "...",
        "threshold": "..."
      }}
    ]
    """
       
    try:
        response = llm.invoke(prompt)
        output = response.content if hasattr(response, "content") else response

        try:
            parsed = json.loads(output)
        except:
            parsed = output

        return {"drl_rules": [parsed]}

    except Exception as e:
        return {"drl_rules": [f"Error: {str(e)}"]}