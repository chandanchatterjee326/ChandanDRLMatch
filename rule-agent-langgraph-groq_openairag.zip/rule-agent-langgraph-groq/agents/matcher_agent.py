import json
from config import get_llm

def matcher_agent(state):
    llm = get_llm()
    drl_rules = state.get("drl_rules", "No DRL rules found")
    dmn_rules = state.get("dmn_rules", "No DMN rules found")

    if isinstance(drl_rules, (dict, list)):
        drl_rules = json.dumps(drl_rules)
    if isinstance(dmn_rules, (dict, list)):
        dmn_rules = json.dumps(dmn_rules)

    prompt = f"""
    Compare DRL and DMN rules.

    DRL:
    {drl_rules}

    DMN:
    {dmn_rules}

    Return:
    [
      {{
        "match": true,
        "reason": "..."
      }}
    ]
    """

    response = llm.invoke(prompt)
    output = response.content if hasattr(response, "content") else response
    output_text = str(output).strip()

    try:
        parsed = json.loads(output_text)
    except json.JSONDecodeError:
        parsed = [output_text]

    return {"results": parsed}
