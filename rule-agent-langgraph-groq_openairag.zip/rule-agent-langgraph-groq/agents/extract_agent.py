def extract_agent(state):
    df = state.get("df")
    rules = state.get("rules")

    if df is None or df.empty or not rules:
        return {"extracted_rules": []}

    rows = df[df["Rule Name"].isin(rules)]
    if rows.empty:
        return {"extracted_rules": []}

    rows = rows.to_dict(orient="records")
    print("Extracted rows:", rows)

    return {"extracted_rules": rows}