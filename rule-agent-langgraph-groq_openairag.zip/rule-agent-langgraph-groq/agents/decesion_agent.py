from config import get_llm
import json

def decision_agent(state):
    llm = get_llm()

    prompt = f"""
    Give final decision with explanation.

    Results:
    {state['results']}

    Return:
    {{
      "decision": "...",
      "reason": "...",
      "matched_rule": "...",
      "confidence": 0-1
    }}
    """

    res = llm.invoke(prompt)

    try:
        parsed = json.loads(res.content)
    except:
        parsed = {"decision": res.content}

    return {"decision": parsed}