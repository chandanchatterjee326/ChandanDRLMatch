from config import get_llm
import json

def intent_agent(state):
    llm = get_llm()
    prompt = f"""
    Understand the user request and extract intent.

    Input: {state['user_prompt']}

    Return JSON:
    {{
      "action": "...",
      "target": "...",
      "logic": "..."
    }}
    """

    res = llm.invoke(prompt)

    try:
        parsed = json.loads(res.content)
    except:
        parsed = {"action": "compare", "target": "all"}

    return {"intent": parsed}