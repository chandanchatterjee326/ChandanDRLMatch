import pandas as pd

def drl_loader(state):
    df = state["df"]

    if df is None or df.empty:
        return {"drl_data": []}

    return {"drl_data": df.to_dict(orient="records")}