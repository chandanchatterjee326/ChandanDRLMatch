import json
from config import get_llm
from utils.rag import create_vector_db, retrieve_context

def dmn_agent(state):
    llm = get_llm()
    text = state.get("dmn_text")

    db = create_vector_db(text)

    query = state.get("user_prompt")
    context = retrieve_context(db, query)

    prompt = f"""
    Extract rules from this relevant context:

    {context}

    Return JSON rules.
    """

    try:
        response = llm.invoke(prompt)
        output = response.content if hasattr(response, "content") else response

        try:
            parsed = json.loads(output)
        except Exception:
            parsed = output

        return {"dmn_rules": parsed}

    except Exception as e:
        return {"dmn_rules": f"LLM Error: {str(e)}"}