import streamlit as st
import pandas as pd
from graph.workflow import build_graph
import os

st.title("Enterprise Rule Validator")

uploaded_drl = st.file_uploader("Upload DRL (Excel)", type=["xlsx", "csv"])
uploaded_dmn = st.file_uploader("Upload DMN Docs", type=["docx"], accept_multiple_files=True)

user_prompt = st.text_input("Enter your request")

graph = build_graph()

if st.button("Run"):
    if not uploaded_drl or not uploaded_dmn:
        st.error("Upload both DRL and DMN files")
    else:
        if uploaded_drl.name.endswith(".xlsx"):
            df = pd.read_excel(uploaded_drl)
        else:
            df = pd.read_csv(uploaded_drl)

        status = st.empty()
        status.write("🔄 Processing DRL...")
        status.write("📄 Extracting DMN...")
        status.write("🔍 Matching rules...")

        with st.spinner("Processing..."):
            result = graph.invoke({
                "df": df,
                "dmn_files": uploaded_dmn,
                "user_prompt": user_prompt
            })

        status.success("✅ Completed")

        st.subheader("✅ Decision")
        st.json(result["decision"])

        st.subheader("📊 Explainability")
        decision = result["decision"]

        st.metric("Decision", decision["decision"])
        st.metric("Confidence", decision["confidence"])

        st.write("Reason:", decision["reason"])
        st.write("Matched Rule:", decision["matched_rule"])

        st.subheader("🧪 Accuracy")
        for r in result["results"]:
            st.progress(r["score"])
            st.write(r["reason"])

        st.subheader("📊 Match Results")
        st.json(result["results"])
    
    