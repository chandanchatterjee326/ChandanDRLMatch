from langgraph.graph import StateGraph, END
from typing import TypedDict, List, Dict, Any

from agents.intent_agent import intent_agent
from agents.drl_loader import drl_loader
from agents.dmn_loader_agent import dmn_loader
from agents.drl_agent import drl_agent
from agents.dmn_agent import dmn_agent
from agents.matcher_agent import matcher_agent
from agents.decesion_agent import decision_agent

class AgentState(TypedDict):
    user_prompt: str
    df: Any
    drl_rules: List
    dmn_text: str
    dmn_rules: List
    results: List
    decision: Dict

def build_graph():
    g = StateGraph(AgentState)

    g.add_node("intent", intent_agent)
    g.add_node("drl_loader", drl_loader)
    g.add_node("dmn_loader", dmn_loader)
    g.add_node("drl_extract", drl_agent)
    g.add_node("dmn_extract", dmn_agent)
    g.add_node("match", matcher_agent)
    g.add_node("decision", decision_agent)

    g.set_entry_point("intent")

    g.add_edge("intent", "drl_loader")
    g.add_edge("drl_loader", "dmn_loader")
    g.add_edge("dmn_loader", "drl_extract")
    g.add_edge("drl_extract", "dmn_extract")
    g.add_edge("dmn_extract", "match")
    g.add_edge("match", "decision")
    g.add_edge("decision", END)

    return g.compile()